## Please note:
The official Swiss Ephemeris documentation is found at https://www.astro.com/ftp/swisseph/doc/

The documentation on Github is in an experimental stage.

We are in process of moving from MS-Word files to Markdown files for easier maintenance 
of the documentation, but the transition is far from complete.

The PDF and HTM files you find in this directory have been automatically created
out of the .md files. See makefile for details of this process.

